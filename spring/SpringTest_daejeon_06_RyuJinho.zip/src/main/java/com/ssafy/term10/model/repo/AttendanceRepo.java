package com.ssafy.term10.model.repo;

public interface AttendanceRepo {

}
