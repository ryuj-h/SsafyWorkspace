package com.ssafy.term10.model.dto;

public class UserInfo {

}

